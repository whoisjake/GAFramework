//
//  ClassSelectionListener.java
//  GAGenerationClassSelector
//
//  Created by Ryan Dixon on Mon Apr 08 2002.
//
//

public interface ClassSelectionListener
{
    public void initializeClassSelection(String classOne, String classTwo);
}
