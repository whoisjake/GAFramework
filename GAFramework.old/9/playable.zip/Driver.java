public class Driver
{
	public static void main( String [ ] args )
	{
		Checkers game = new Checkers();
		game.show();
	}
}